package com.Q12_2;

public class Timer1 implements Runnable {

	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println("Alert" + i);

			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				System.out.println("Thread Is Interuptted When It Is Sleeping" + e);
			} finally {
				System.out.println("Done");
			}
		}

	}

}
