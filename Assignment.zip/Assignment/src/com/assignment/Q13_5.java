package com.assignment;

import java.util.Scanner;
import java.util.function.Function;

public class Q13_5 {
	public static void main(String args[])

	{
		long fact = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a Number: ");
		
		int num = scanner.nextInt();

		Function<Long, Long> factorial = Q13_5::factCal;
		Long result = factorial.apply((long) num);
		System.out.println("Factorial Of "+num+"----> "+result);

	}

	static long factCal(long num) {
		long fact = 1;
		for (int i = 1; i <= num; i++) {

			fact = fact * i;

		}
		return fact;
	}

}
