package com.assignment;


interface CalculatePower {
	void power(int x,int y);
}


public class Q13_1 {
	public static void main(String args[]) {
		
	CalculatePower calculatePower = (x, y) -> System.out.println(Math.pow(x, y));
	calculatePower.power(6,3);
	}
}