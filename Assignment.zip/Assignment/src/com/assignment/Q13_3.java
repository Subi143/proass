package com.assignment;

import java.util.Scanner;

interface User {

	public String valid(String username, String password);
}

public class Q13_3 {
	public static void main(String args[]) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Username: ");
		String username = scanner.next();
		System.out.print("\nEnter Password: ");
		String password = scanner.next();
		System.out.println();
		User user = (String us1, String pw1) -> {
			if (username.contains("aa") && password.contains("@")) {
				return "Welcome";
			} else {
				return "Exit";
			}
		};
		System.out.println(user.valid(username, password));
	}
}